# -- coding: utf-8 --
utf='# -- coding: utf-8 --'
print ("Eu gosto de açaí") 
print ("Para exibir caracteres especiais devemos inserir %r" %(utf)) 