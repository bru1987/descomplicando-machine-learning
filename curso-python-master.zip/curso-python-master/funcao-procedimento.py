# -*- coding: utf-8 -*-

# Criando uma função em Python
def produto(a,b):
    return a*b

# Programa
print ("The Sum Program")
a = int(input("Insira o primeiro valor: "))
b = int(input("Insira o primeiro valor: "))
print(a)
print(b)
c = produto(a, b)
print ("Produto entre " + str(b) + " e " + str(b) + ": "+str(c))
