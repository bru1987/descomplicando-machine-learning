# -*- coding: utf-8 -*-
print 'A'
print "Nova string"
print 'Fazer o quê?!'
