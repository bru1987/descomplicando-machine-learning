# -*- coding: utf-8 -*-

# A operação abaixo mostra se a condição é verdadeira ou falsa
print (2>5)

# A operação baixo mostra o valor de fato da operação de divisão. Como usamos
# números inteiros, todo e qualquer número decimal será ignorado.
print (7/6)

# A operação baixo mostra o valor de fato da operação de divisão
print (7.0/6.0)

# O operador abaixo % mostra o resto da divisão de dois números
print (32%5)
